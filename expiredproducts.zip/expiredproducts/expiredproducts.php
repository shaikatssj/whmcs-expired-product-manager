<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

/**
 * Module Configuration
 */
function expiredproducts_config() {
    return [
        'name' => 'Expired Products Manager',
        'description' => 'Manage and track expired & soon-to-expire products for better customer notifications.',
        'author' => 'Hostinoz.com',
        'language' => 'english',
        'version' => '1.8',
        'fields' => [
            [
                'name' => 'premium',
                'label' => 'Enable Premium Features',
                'type' => 'yesno',
                'description' => 'Unlock advanced reporting and automated alerts.',
                'default' => 'no',
            ],
            [
                'name' => 'logo',
                'label' => 'Module Logo',
                'type' => 'text',
                'description' => 'URL/path to the logo (Recommended: 100x100px).',
                'default' => 'modules/expiredproducts/logo.png',
            ],
        ],
    ];
}

/**
 * Admin Area Output
 */
function expiredproducts_output($vars) {
    $modulelink = $vars['modulelink'];
    $products = Capsule::table('tblhosting')
    ->whereIn('domainstatus', ['Active', 'Suspended'])
    ->join('tblproducts', 'tblhosting.packageid', '=', 'tblproducts.id')
    ->join('tblclients', 'tblhosting.userid', '=', 'tblclients.id')
    ->select(
        'tblhosting.*',
        'tblproducts.name as package_name',
        'tblclients.firstname',
        'tblclients.lastname'
    )
    ->get();

    $currentDate = time();

    echo '<style>
    body { font-family: "Poppins", sans-serif; margin: 0; padding: 0; background: #f4f6f9; }
    .container { width: 90%; margin: auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }
    .section-title { margin-top: 20px; font-size: 1.2em; font-weight: bold; color: #444; border-left: 5px solid #0073e6; padding-left: 10px; }
    .product-card { background: #fff; border-radius: 8px; padding: 15px; margin-bottom: 10px; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1); }
    .product-card strong { display: block; font-size: 14px; color: #333; }
    .expired { border-left: 5px solid #d9534f; }
    .recently-expired { border-left: 5px solid #d39e00; }
    .expiring { border-left: 5px solid #28a745; }
    .product-link { color: #0073e6; text-decoration: none; font-weight: bold; transition: 0.3s; }
    .product-link:hover { color: #005bb5; }

    /* Responsive Table for Larger Screens */
    @media (min-width: 769px) {
        .product-card { display: none; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; font-size: 14px; }
        th { background: #343a40; color: white; }
    }

    /* Mobile View - Cards Instead of Table */
    @media (max-width: 768px) {
        table { display: none; }
        .container { width: 100%; padding: 10px; }
        .product-card strong { font-size: 16px; }
    }
    </style>';

    echo '<div class="container">';

    function displayProducts($products, $title, $class, $currentDate, $daysRange) {
        echo '<h2 class="section-title">' . $title . '</h2>';
        echo '<table>
        <tr><th>Client</th><th>Package</th><th>Domain</th><th>Days Left/Expired</th><th>Status</th></tr>';

        foreach ($products as $product) {
            $nextDueDate = strtotime($product->nextduedate);
            $daysUntilExpiry = floor(($nextDueDate - $currentDate) / (60 * 60 * 24));

            if (($daysRange == "expired" && $daysUntilExpiry < -7) ||
                ($daysRange == "recently_expired" && $daysUntilExpiry < 0 && $daysUntilExpiry >= -7) ||
                ($daysRange == "expiring" && $daysUntilExpiry > 0 && $daysUntilExpiry <= 7)) {

                // Table View for Desktop
                echo '<tr class="' . $class . '">
            <td>' . $product->firstname . ' ' . $product->lastname . '</td>
            <td><a href="clientshosting.php?userid=' . $product->userid . '&id=' . $product->id . '" target="_blank" class="product-link">' . $product->package_name . '</a></td>
            <td>' . $product->domain . '</td>
            <td>' . ($daysUntilExpiry < 0 ? abs($daysUntilExpiry) . ' days ago' : $daysUntilExpiry . ' days left') . '</td>
            <td>' . $product->domainstatus . '</td>
            </tr>';

                // Mobile View - Card Style
            echo '<div class="product-card ' . $class . '">
            <b>Client:</b> ' . $product->firstname . ' ' . $product->lastname . '<br>
            <b>Package:</b> <a href="clientshosting.php?userid=' . $product->userid . '&id=' . $product->id . '" target="_blank" class="product-link">' . $product->package_name . '</a><br>
            <b>Domain:</b> ' . $product->domain . '<br>
            <b>' . ($daysUntilExpiry < 0 ? 'Expired' : 'Expires in') . ':</b> ' . ($daysUntilExpiry < 0 ? abs($daysUntilExpiry) . ' days ago' : $daysUntilExpiry . ' days left') . '<br>
            <b>Status:</b> <span style="font-weight: bold; color: ' . ($product->domainstatus == 'Active' ? 'green' : ($product->domainstatus == 'Suspended' ? 'red' : 'black')) . ';">' . $product->domainstatus . '</span>
            </div>';

        }
    }
    echo '</table>';
}

    // Show different sections
displayProducts($products, "Recently Expired (Last 7 Days)", "recently-expired", $currentDate, "recently_expired");
displayProducts($products, "All Expired Products", "expired", $currentDate, "expired");
displayProducts($products, "Expiring in Next 7 Days", "expiring", $currentDate, "expiring");

echo '</div>';
}
